const express = require('express');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY';
const SCRAPINGBEE_API_KEY = 'YOUR_SCRAPINGBEE_API_KEY';

// Middleware to parse JSON data
app.use(express.json());

// Endpoint to fetch search results using Custom Search API
app.post('/search', async (req, res) => {
  try {
    const query = req.body.query;
    const searchResults = await getSearchResults(query);
    const pageTexts = await scrapeUrls(searchResults);
    res.json(pageTexts);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Function to fetch search results using Custom Search API
async function getSearchResults(query) {
  const url = `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_API_KEY}&cx=YOUR_CUSTOM_SEARCH_ENGINE_ID&q=${query}&num=5`;
  const response = await axios.get(url);
  return response.data.items.map(item => item.link);
}

// Function to scrape the text from the URLs using ScrapingBee API
async function scrapeUrls(urls) {
  const pageTexts = [];
  for (const url of urls) {
    const response = await axios.get(`https://app.scrapingbee.com/api/v1/?api_key=${SCRAPINGBEE_API_KEY}&url=${encodeURIComponent(url)}`);
    pageTexts.push(response.data.text);
  }
  return pageTexts;
}

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
